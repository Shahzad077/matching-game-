class LevelModel {
  final id;
  final String? name;
  final String? value;
  final String? ImagePath;
  bool isSelected;
  bool accepting;
  LevelModel(
      {this.id,
      this.name,
      this.value,
      this.ImagePath,
      this.accepting = false,
      this.isSelected = false});
}
