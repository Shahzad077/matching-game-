import 'package:flutter/material.dart';

class RowWidget extends StatelessWidget {
  final String imagepath;
  final VoidCallback onpressedImage;
  final VoidCallback onpressedText;
  final String text;
  final Color color;
  const RowWidget(
      {Key? key,
      required this.text,
      required this.color,
      required this.onpressedImage,
      required this.onpressedText,
      required this.imagepath})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          GestureDetector(
            onTap: onpressedImage,
            child: Image.asset(
              imagepath,
              height: 100,
              width: 100,
            ),
          ),
          Spacer(),
          GestureDetector(
            onTap: onpressedText,
            child: Container(
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(17), color: Colors.white),
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Text(
                  text,
                  style: TextStyle(
                      fontSize: 30,
                      color: color,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Bradley Hand'),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
