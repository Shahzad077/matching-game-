import 'package:avatar_glow/avatar_glow.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:matching_game/screens/first_level_screen.dart';

import '../level_model.dart';

class PlayButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return AvatarGlow(
      startDelay: Duration(milliseconds: 1000),
      glowColor: Colors.white,
      endRadius: 160.0,
      duration: Duration(milliseconds: 2000),
      repeat: true,
      showTwoGlows: true,
      repeatPauseDuration: Duration(milliseconds: 100),
      child: MaterialButton(
        onPressed: () {
          Get.to(FirstLevelScreen(
            list: [
              LevelModel(
                  id: 1,
                  ImagePath: "assets/1.jpg",
                  name: "1",
                  value: "1",
                  isSelected: false),
              LevelModel(
                  id: 2,
                  ImagePath: "assets/2.jpg",
                  name: "2",
                  value: "2",
                  isSelected: false),
              LevelModel(
                  id: 3,
                  ImagePath: "assets/3.jpg",
                  name: "3",
                  value: "3",
                  isSelected: false),
              LevelModel(
                  id: 4,
                  ImagePath: "assets/4.jpg",
                  name: "4",
                  value: "4",
                  isSelected: false),
              LevelModel(
                  id: 5,
                  ImagePath: "assets/5.jpg",
                  name: "5",
                  value: "5",
                  isSelected: false),
            ],
          ));
        },
        elevation: 20.0,
        shape: CircleBorder(),
        child: Container(
          width: 200.0,
          height: 200.0,
          alignment: Alignment.center,
          decoration: BoxDecoration(
              color: Colors.white, borderRadius: BorderRadius.circular(160.0)),
          child: Text(
            "GO",
            style: TextStyle(
                fontSize: 75.0,
                fontWeight: FontWeight.w800,
                color: Color(0xFF7557D6)),
          ),
        ),
      ),
    );
  }
}
