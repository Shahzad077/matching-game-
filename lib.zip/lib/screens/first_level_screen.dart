import 'package:assets_audio_player/assets_audio_player.dart';
import 'package:flutter/material.dart';

import '../level_model.dart';

class FirstLevelScreen extends StatefulWidget {
  final List<LevelModel> list;
  const FirstLevelScreen({Key? key, required this.list}) : super(key: key);
  @override
  State<FirstLevelScreen> createState() => _FirstLevelScreenState();
}

class _FirstLevelScreenState extends State<FirstLevelScreen> {
  int _selectedIndex = 0;
  List<LevelModel>? items;
  List<LevelModel>? items2;

  int score = 0;
  bool gameOver = false;
  void initState() {
    super.initState();
    initGame();
  }

  initGame() {
    gameOver = false;
    score = 0;
    items = widget.list;
    items2 = List<LevelModel>.from(items!);
    items?.shuffle();
    items2?.shuffle();
  }

  void myFunction(String name) {
    final player = AssetsAudioPlayer();
    player.open(
      Audio(name),
    );
    print(name);
  }

  var question;
  var answer;

  @override
  Widget build(BuildContext context) {
    if (items?.length == 0) {
      return FirstLevelScreen(list: [
        LevelModel(
            id: 1,
            ImagePath: "assets/1.jpg",
            name: "1",
            value: "1",
            isSelected: false),
        LevelModel(
            id: 2,
            ImagePath: "assets/2.jpg",
            name: "2",
            value: "2",
            isSelected: false),
        LevelModel(
            id: 3,
            ImagePath: "assets/3.png",
            name: "3",
            value: "3",
            isSelected: false),
        LevelModel(
            id: 4,
            ImagePath: "assets/4.jpg",
            name: "4",
            value: "4",
            isSelected: false),
        LevelModel(
            id: 5,
            ImagePath: "assets/5.jpg",
            name: "5",
            value: "5",
            isSelected: false),
        LevelModel(
            id: 6,
            ImagePath: "assets/6.jpg",
            name: "6",
            value: "6",
            isSelected: false),
        LevelModel(
            id: 7,
            ImagePath: "assets/7.jpg",
            name: "7",
            value: "7",
            isSelected: false),
        LevelModel(
            id: 8,
            ImagePath: "assets/8.jpg",
            name: "8",
            value: "8",
            isSelected: false),
        LevelModel(
            id: 9,
            ImagePath: "assets/9.jpg",
            name: "9",
            value: "9",
            isSelected: false),
        LevelModel(
            id: 10,
            ImagePath: "assets/10.jpg",
            name: "10",
            value: "10",
            isSelected: false),
      ]);
    } else {
      return Stack(
        children: [
          Container(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            color: Colors.lightBlue,
          ),
          Scaffold(
            backgroundColor: Colors.transparent,
            appBar: AppBar(
              title: Text("Matching Game"),
              backgroundColor: Colors.white12,
            ),
            body: Padding(
              padding: const EdgeInsets.all(10.0),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Container(
                        decoration: BoxDecoration(
                            border: Border.all(
                              color: Colors.black,
                            ),
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(17)),
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Text(
                            "Match the Hands finger with Number on left side",
                            style: TextStyle(
                                fontSize: 20,
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Apple SD Gothic Neo'),
                          ),
                        ),
                      ),
                    ),
                    Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Column(
                            children: items!.map((item) {
                              return GestureDetector(
                                onTap: () {
                                  question = item;
                                },
                                child: Padding(
                                  padding: const EdgeInsets.only(bottom: 10),
                                  child: Draggable<LevelModel>(
                                    data: item,
                                    feedback: Image.asset(
                                      item.ImagePath ?? "",
                                      height: 100,
                                      width: 100,
                                    ),
                                    childWhenDragging: Image.asset(
                                      item.ImagePath ?? "",
                                      height: 100,
                                      width: 100,
                                    ),
                                    child: Image.asset(
                                      item.ImagePath ?? "",
                                      height: 100,
                                      width: 100,
                                    ),
                                  ),
                                ),
                              );
                            }).toList(),
                          ),
                          Spacer(),
                          Column(
                            children: items2!.map((item) {
                              return Padding(
                                  padding: const EdgeInsets.only(bottom: 40),
                                  child: DragTarget<LevelModel>(
                                    onAccept: (receivedItem) {
                                      if (item.value == receivedItem.value) {
                                        myFunction("assets/sound/correct.wav");
                                        const snackBar = SnackBar(
                                          content: Text(
                                            'Correct Match',
                                            style: TextStyle(
                                                fontSize: 25,
                                                fontWeight: FontWeight.bold),
                                          ),
                                          backgroundColor: Colors.green,
                                        );
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(snackBar);
                                        setState(() {
                                          items?.remove(receivedItem);
                                          items2?.remove(item);
                                          score += 10;
                                          item.accepting = false;
                                        });
                                      } else {
                                        myFunction("assets/wrong.wav");
                                        const snackBar = SnackBar(
                                          content: Text(
                                            'Wrong Match',
                                            style: TextStyle(
                                                fontSize: 25,
                                                fontWeight: FontWeight.bold),
                                          ),
                                          backgroundColor: Colors.red,
                                        );
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(snackBar);
                                        setState(() {
                                          score -= 5;
                                          item.accepting = false;
                                        });
                                      }
                                    },
                                    onLeave: (receivedItem) {
                                      setState(() {
                                        item.accepting = false;
                                      });
                                    },
                                    onWillAccept: (receivedItem) {
                                      setState(() {
                                        item.accepting = true;
                                      });
                                      return true;
                                    },
                                    builder: (context, acceptedItems,
                                            rejectedItem) =>
                                        GestureDetector(
                                      onTap: () {
                                        answer = item;
                                        if (question.id == answer.id) {
                                          myFunction(
                                              "assets/correct.wav");
                                          const snackBar = SnackBar(
                                            content: Text(
                                              'Correct Match',
                                              style: TextStyle(
                                                  fontSize: 25,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            backgroundColor: Colors.green,
                                          );
                                          ScaffoldMessenger.of(context)
                                              .showSnackBar(snackBar);
                                          setState(() {
                                            items?.remove(question);
                                            items2?.remove(answer);
                                          });
                                        } else {
                                          myFunction("assets/sound/wrong.wav");
                                          const snackBar = SnackBar(
                                            content: Text(
                                              'Wrong Match',
                                              style: TextStyle(
                                                  fontSize: 25,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            backgroundColor: Colors.red,
                                          );
                                          ScaffoldMessenger.of(context)
                                              .showSnackBar(snackBar);
                                          setState(() {
                                            score -= 5;
                                            item.accepting = false;
                                          });
                                        }
                                      },
                                      child: Container(
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(17),
                                            color: item.accepting == false
                                                ? Colors.white
                                                : Colors.green),
                                        child: Padding(
                                          padding: const EdgeInsets.all(20.0),
                                          child: Text(
                                            item.name ?? "",
                                            style: TextStyle(
                                                fontSize: 30,
                                                color: Colors.red,
                                                fontWeight: FontWeight.bold,
                                                fontFamily: 'Bradley Hand'),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ));
                            }).toList(),
                          ),
                        ]),
                  ],
                ),
              ),
            ),
            bottomNavigationBar: BottomNavigationBar(
                items: const <BottomNavigationBarItem>[
                  BottomNavigationBarItem(
                      icon: Icon(Icons.eleven_mp_outlined),
                      label: 'Level 1',
                      backgroundColor: Colors.deepPurple),
                  BottomNavigationBarItem(
                      icon: Icon(Icons.leaderboard),
                      label: 'Level 2',
                      backgroundColor: Colors.deepPurple),
                ],
                type: BottomNavigationBarType.shifting,
                currentIndex: _selectedIndex,
                selectedItemColor: Colors.black,
                iconSize: 40,
                elevation: 5),
          ),
        ],
      );
    }
  }
}
// Container(
// decoration: BoxDecoration(
// borderRadius: BorderRadius.circular(17),
// color: Colors.white),
// child: Padding(
// padding: const EdgeInsets.all(20.0),
// child: Text(
// (item.value ?? "").toString(),
// style: TextStyle(
// fontSize: 30,
// color: Colors.red,
// fontWeight: FontWeight.bold,
// fontFamily: 'Bradley Hand'),
// ),
// ),
// ),
